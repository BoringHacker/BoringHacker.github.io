---
title: 数据结构100题 ---树状数组
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-05 14:51:04
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-4.png
mathjax: true
---

# 树状数组

($nlogn$)

树状数组是一种常数较小的，能够实现区间加法，区间查询的数据结构。

其中最玄妙的操作就是$lowbit$了,它是使树状数组常数进一步缩小的功臣。

#### 1).lowbit

这个操作用来找到$x$从右往左数的第一个为1的位。

先看一看这个操作的实现吧：$lowbit(x)=(x$&$(-x))$ ($x$一般为正整数)

说它很玄妙是因为它很短，但很有效；它充分地利用了位运算的高效。

但我们要理解它的原理。

位运算嘛，我们先把x转化成2进制补码。那么x是正整数，它的二进制补码就是他自身，且其中肯定有一个1。

$-x$的二进制表示则是它的二进制表示的反码+1；即把除符号位外的所有位取反，再$+1$。

我们把这两个步骤分开，先把所有位取反，此时x与它与起来等于0。再$+1$，就会使从右往左数第一个为零的位变为1：因为如果第一位是0，那么这位就会变成1；否则就会往前进1位，经过递归，就能使从右往左数第一个为零的位变为1。

从右往左数第一个为零的位的左边的数没有被改变过，所以与起来依然是0；右边的数经过进位都变成了0，不管怎样与都是0。而这一位本身现在是1，原来是0，说明这一位原来是1，与起来就是1。而这一位是第一个为0的位，那么它原来就是第一个为1的位。

#### 2).单点修改

首先我们定义一个$nodes$数组。

$nodes[i]$储存$a[i-lowbit(i)+1]$到$a[i]$的和。

那么如果我们给$a[i]$加上了$x$,那么$nodes[i]$肯定包括$a[i]$，也要加上$x$;

$lowbit(i+lowbit(i))$的值肯定大于$lowbit(i)$,所以$nodes[i+lowbit(i)]$也要加上$x$;

再继续递归下去，一直到数组的边界为止。

那如何说明$nodes[i+lowbit(i)]$就是第一个包含$nodes[i]$的数呢？

我们按照$lowbit(i)$把$nodes[MAXN]$分为$log(MAXN)$层，那么不可能有同层及下层节点包含$nodes[i]$，除了它自己。

所以我们向上层节点寻找，就要把$lowbit(i)$这一位消掉且数字要增大，直接加上$lowbit(i)$就可以做到这一点，因为$lowbit(i)$这一位往右都是0，要把这一位消掉，需要加上的数中没有比$lowbit(i)$更小的。

所以$nodes[i+lowbit(i)]$就是第一个包含$nodes[i]$的数。

代码
```
void update(int x,int val)
{
	while(x<=MAXN)
	{
		nodes[x]+=val;
		x+=lowbit(x);
	}
}
```

#### 3).区间查询（单点修改）

如果我们要查询区间$[l,r]$的和，我们可以运用前缀和思想，把它转换成求$[1,r]-[1,l-1]$的值。

那么问题转化成了求区间$[1,x]$的和。

由于定义，$nodes[x]$储存的是$a[x-lowbit(x)+1]$到$a[x]$的和，那么我们可以进一步缩小问题规模：$query[1,x]=query[1,x-lowbit(x)]+nodes[x]$,一直到0为止。

代码
```
int ask(int x)
{
	int res=0;
	while(x)
	{
		res+=nodes[x];
		x-=lowbit(x);
	}
	return res;
}
int query(int l,int r)
{
	return ask(r)-ask(l-1);
}
```

#### 4).区间修改及查询

上面的操作只支持单点修改，那么如何区间修改呢，一个一个地改肯定会炸。我们采用差分的思想，将区间修改转化为单点修改。

我们先思考如何用差分数组$c[n]$求$a[1]+a[2]+\cdots+a[n-1]+a[n]$。

$c[1]*n+c[2]*(n-1)+\cdots+c[n-1]*2+c[n]$

这个式子里的c[i]和i没有什么关系，不太好操作，于是我们把它变个形：

$(c[1]+c[2]+\cdots+c[n-1]+c[n])*(n+1)-(c[1]+c[2]*2+\cdots+c[n-1]*(n-1)+c[n]*n)$

这样就好维护多了：我们只需要开两个树状数组维护$c[1]+c[2]+\cdots+c[i]$和$c[1]+c[2]*2+\cdots+c[i]*i$($nodes[MAXN]$,$exnodes[MAXN]$)

对于一个区间修改——$[l,r]$加$x$。

将所有包含$c[l]$的$nodes$加$x$,$exnodes$加$l*x$($(c[l]+x)*l==c[l]*l+x*l$)

将所有包含$c[r+1]$的$nodes$减$x$,$exnodes$减$(r-1)*x$($(c[r+1]+x)*(r+1)==c[r+1]*(r+1)+x*(r+1)$)

对于一个区间询问——$[l,r]$

等价于$[1,r]-[1,l-1]$

对于$[1,x]$

由上面的式子得出做法:以$nodes$查询$(c[1]+c[2]+\cdots+c[x-1]+c[x])*(x+1)$，以$exnodes$查询$(c[1]+c[2]*2+\cdots+c[x-1]*(x-1)+c[x]*x)$,再将它们相减。

代码
```
void update(int x,int val)
{
	while(x<=MAXN)
	{
		nodes[x]+=val;
		x+=lowbit(x);
	}
}
void exupdate(int x,int val)
{
	while(x<=MAXN)
	{
		exnodes[x]+=val;
		x+=lowbit(x);
	}
}
int find(int x)
{
	int res=0;
	while(x)
	{
		res+=nodes[x];
		x-=lowbit(x);
	}
	return res;
}
int exfind(int x)
{
	int res=0;
	while(x)
	{
		res+=exnodes[x];
		x-=lowbit(x);
	}
	return res;
}
void modify(int l,int r,int x)
{
	update(l,x);
	exupdate(l,l*x);
	update(r+1,-x);
	exupdate(r+1,-(r+1)*x);
}
int ask(int x)
{
	return find(x)*(x+1)-exfind(x);
}
int query(int l,int r)
{
	return ask(r)-ask(l-1);
}
```

//(下面两个先咕了，我没看到哪道题要用……)
#### 5).二维单点修改，区间查询

#### 6).二维区间修改，区间查询