---
title: 数据结构100题 ---Chtholly-Tree(Old-Driver Tree)
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-07 14:51:04
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-14.png
mathjax: true
---

# Chtholly-Tree

## 众所周知，数据结构+算法=程序，可见数据结构的重要性



数据结构占了我们编程的一大部分。数据结构的大家族中，有优美的线段树、树状数组等。但我们今天的主角却十分暴力。她的名字叫珂朵莉树



`珂朵莉树是基于C++STL库中的set的数据结构。与线段树、平衡树等树形结构类似，珂朵莉树是用来解决区间问题的很暴力的树形结构。`



她的特点是能够进行区间推平操作，并且时间复杂度接近O(n log m) 。但前提是数据随机。但一般不会有哪个出题人去卡这样一个并不出名的数据结构。并且要有区间推平操作，否则光是一个split时间复杂度会炸。



珂朵莉树的构造长成这个亚子:



```cpp
struct Chtholly
{
    LL L;
    LL R;		//区间
    mutable LL _val; //值，注意，关键字mutable是必需的，否则会在add函数里CE
    
    
    node(LL l, LL r = -1, LL V = 0) : L(l), R(r), _val(V) {}
    bool operator<(const node &rhs) const { return L < rhs.L; }
}
```



Split操作:



```cpp
inline IT split(int k) {
    IT it = st.lower_bound(node(k));
    if (it != st.end() && it->L == k)
        return it;
    --it;
    LL l = it->L, r = it->R;
    LL v = it->_val;
    st.erase(it);
    st.insert(node(l, k - 1, v));
    return st.insert(node(k, r, v)).first;
}
```



为了操作方便我们这里有一个define:

```cpp
#define IT set<Chtholly>::iterator
```



assign区间推平操作，这也是珂朵莉树的时间复杂度保证



```cpp
inline void assign(LL ll, LL rr, LL val) {
    IT itr = split(rr + 1), itl = split(ll);
    st.erase(itl, itr);
    st.insert(node(ll, rr, val));
}
```



举几个例子吧



### 区间求和:



```cpp
inline LL Qsum(LL ll, LL rr) {
    LL res = 0;
    IT itr = split(rr + 1), itl = split(ll);
    for (; itl != itr; ++itl) res += (itl->R - itl->L + 1) * itl->_val;
    return res;
}
```



### 区间第K小:



```cpp
inline LL kth(LL ll, LL rr, LL k) {
    vector<pair<LL, LL> > vec;
    IT itr = split(rr + 1), itl = split(ll);

    for (; itl != itr; ++itl) vec.push_back(pair<LL, LL>(itl->_val, itl->R - itl->L + 1));
    sort(vec.begin(), vec.end());

    for (auto it = vec.begin(); it != vec.end(); ++it) {
        k -= it->second;
        if (k <= 0)
            return it->first;
    }
    return -1;
}

```



### 区间加



```cpp
inline void add(LL ll, LL rr, LL ad) {
    IT itr = split(rr + 1), itl = split(ll);
    for (; itr != itl; ++itl) itl->_val += ad;
}
```

平时大家还是尽量少用······