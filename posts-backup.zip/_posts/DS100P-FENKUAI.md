---
title: 数据结构100题 ---分块
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-07 14:51:04
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-13.png
mathjax: true
---

# 分块

($n\sqrt n$)

分块其实也是一种暴力，~~但它是一种巧妙的暴力~~

它用来处理区间的问题。

把这个区间大概分成$\sqrt n$块

然后再处理：对于一个整块，就整个处理掉；对于一个角块（不完整的块），就暴力处理。

比如区间求和。(非主流写法勿喷)

### 1.初始化

对于每个元素，我们要处理出它是哪个块的，以便之后快速地找到它所在的块。

对于每个块，我们要统计出之后计算答案所需这个块内的结果（这里就是块内区间和），在区间中的左右端点，以及区间修改的懒标记。

代码：
```
struct cude
{
	int l,r,sum,lazy;//左右端点，区间和，懒标记
}cud[400];
int n,a[100010],bel[100010],each,cnt;//原数组大小及元素，每个元素的块编号，块大小，块数
void build()
{
	each=sqrt(n);
	for(int i=0;i<n;++i)//注意，我是从0开始存的原数组
	{
		bel[i]=i/each;//预处理元素属于块
		cud[bel[i]].sum+=a[i];//区间和
	}
	for(int i=0;i*each<n;++i)
	{
    		++cnt;//统计块数
		cud[i].l=i*each;//块左端点
		cud[i].r=min((i+1)*each-1,n-1);//块右端点，不可能达到n，所以取min，最多到n-1
	}
}
```

### 2.修改

修改是很暴力的，我们对这个区间进行扫描。

整块就区间修改，懒标记。

角块就直接暴力扫过去修改。

最多$\sqrt n$个整块，打懒标记$O(1)$，复杂度为$O(\sqrt n)$

最多$2$个角块，一个角块最多$\sqrt n$个元素，暴力修改$O(\sqrt n)$

区间修改总时间复杂度$O(\sqrt n)$

代码：
```
void update(int l,int r,int val)
{
	for(int i=bel[l];cud[i].l<=r&&i<cnt;++i)//注意不要超过块数，我的块是从0开始编号的
	{
		if(cud[i].l>=l&&cud[i].r<=r)//整块打懒标记
		{
			cud[i].lazy+=val;
			cud[i].sum+=(cud[i].r-cud[i].l+1)*val;
		}
		else//角块暴力扫
		{
			if(cud[i].l<l)//属于整个区间的最左边的角块，但还可能是最右边的角块，需要判断不要超出修改区间的右端点
			{
				for(int j=l;j<=cud[i].r&&j<=r;++j)
				{
					a[j]+=val;
					cud[i].sum+=val;
				}
			}
			else//不是最左边的，那肯定是最右边的。
			{
				for(int j=cud[i].l;j<=r;++j)
				{
					a[j]+=val;
					cud[i].sum+=val;
				}
			}
		}
	}
}
```

### 3.查询

查询也是很暴力的。

同样对这个区间进行扫描。

如果是整块，就直接加上这个块的区间和。

如果是角块，就要先下传懒标记，再暴力查询。

因为我们之前并没有修改元素值，只是加上了懒标记，修改了区间和。

所以我们现在要先修改这些元素的值再查询，否则查询到的值是修改之前的。

时间复杂度与修改相同，都是$O(\sqrt n)$；

代码：
```
//细节同2.修改
int find(int l,int r)
{
	int res=0;
	for(int i=bel[l];cud[i].l<=r&&i<cnt;++i)
	
		if(cud[i].l>=l&&cud[i].r<=r)	res+=cud[i].sum;
		else
		{
			if(cud[i].lazy)//下传懒标记
			{
				for(int j=cud[i].l;j<=cud[i].r;++j)	a[j]+=cud[i].lazy;
				cud[i].lazy=0;
			}
			if(cud[i].l<l)
			{
				for(int j=l;j<=cud[i].r&&j<=r;++j)	res+=a[j];
			}
			else
			{
				for(int j=cud[i].l;j<=r;++j)	res+=a[j];
			}
		}
	}
	return res;
}
```

### 4.总结

你看着这个东西好像很暴力，但它就是跑得过题。

它的总时间复杂度是$O(n\sqrt n)$的，$500000$及以上就别想啦。

分块的题目很灵活，但一般都很暴力，有时区间修改不能打懒标记，就必须暴力修改，但有时你又可以跳过这个修改，进行“剪枝”。

就像[花神游历各国](http://222.180.160.110:1024/problem/133)，区间开方必须要在块里去暴力开

但我们想，$1$和$0$开方后都是本身，其它数开方就会变得越来越小，最后到$1$，所以我们可以维护一个块内是否全是$1$或$0$。

如果是，就可以跳过在这个区间里进行开方了，因为这个块里的元素开方之后都还是本身，每个元素和区间和都没有变。

其他的就是普通分块。

$\ $

~~在分块，你甚至可以打表~~

在区间中选取$\sqrt n$个特征点，处理出它们间的信息。

对每个查询，选取最近的两个特征点的信息再从这两个特征点暴力跳过去。

这样就可以代替莫队啦。

而且分块没有任何离线操作，可以应对看起来像要用莫队（离线算法，同样$O(n\sqrt n)$）才能解决，但又强制在线的题目。

以及，**整除分块不是数据结构，是数论！！！**