---
title: 数据结构100题 ---fhq-treap
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-05 14:51:05
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-3.png
mathjax: true
---

# fhq-treap

($nlogn$)

$fhq-treap$是一种二叉搜索树。满足二叉搜索树的性质：中序遍历是一个不降序列。也就是说，一个节点的左儿子小于等于它，右儿子大于等于它。

但它和$treap$一样，都满足堆的性质：任意父节点的键值大于(等于)或小于(等于)子节点的键值。

它可以做普通平衡树（基本操作），文艺平衡树（区间操作），还可以可持久化。

但常数略大。

定义：
```
struct node
{
	int l,r,num,key,cum;
   	//左儿子，右儿子，本节点的值，键值，子树大小
}nodes[MAXN];
```

### 1.权值fhq-treap

权值$fhq-treap$的意思是，它这时候既满足二叉搜索树的性质，又满足堆的性质。

先讲讲辅助操作吧：

**update**:用来更新当前节点的子树大小。

代码实现：

```
void update(int x)
{
	nodes[x].cum=nodes[nodes[x].l].cum+nodes[nodes[x].r].cum+1;
}
```
因为一个节点的子树大小等于它左右儿子的子树大小加上它本身嘛。

**newnode**:新建一个值为指定值的节点并返回它的编号。

代码实现：
```
int newnode(int val)
{
	nodes[++tot].cum=1;
    	nodes[tot].num=val;
        nodes[tot].key=rand();
        return tot;
}
```

主要操作有两个：

#### 1>.分裂split

这里的分裂按照权值分裂，即把原树按照权值$val$分成两棵树，一棵$X$中的权值全部小于等于$val$，另一棵y的权值全部大于$val$。而这两棵树都要满足两个性质。

要实现这个操作，我们要从根节点开始遍历，把整棵树分成两半。

我们进行分类讨论：现在遍历到的节点编号为$now$。

1).当$now=0$时

这时，now是一个空节点，没有办法分裂。

2).当$nodes[now].num\leq val$时

这个节点以及它的左子树的权值都小于等于$val$,那么他们全部都属于$X$。

那么它的右子树可能是$X$的，也可能是$Y$的。

所以我们需要继续分裂右子树，但由于右边的数要比$nodes[now].num$大，接下来分裂出的小于等于$val$的子树需要接在当前分出的$X$树的右子树上。

3).否则

这个时候这个节点和它的右子树的权值都大于$val$，那么他们全部属于$Y$。

但它的左子树可能有一部分属于$X$。

所以我们需要继续分裂左子树。道理同上。

上面操作已经保证了分出的二叉树满足二叉树性质。而堆性质也得到了满足，因为从原树上往下分，分到节点的键值也是有序的。

递归返回前还要记得$update$一下，更新分裂后的子树大小。

是不是还是不懂？还是看代码和代码注释吧：
```
//x,y代表从now这个节点分裂出的两棵树的根节点，使用引用返回值。
void split(int now,int val,int &x,int &y)
{
	if(!now)	x=y=0;//情况1).无法继续分裂，所以两棵树都是空。
	else
	{
		if(nodes[now].num<=val)//情况2).
		{
			x=now;//左子树和这个节点都属于X树，接到之前分裂到的地方。右子树在下面会受到修改，所以右子树并没有被直接包括。
			split(nodes[now].r,val,nodes[x].r,y);//继续分裂右子树。接下来分裂出属于X树的根节点位置应该是nodes[x].r，y的位置没有变动。
		}
		else//情况3).
		{
			y=now;
			split(nodes[now].l,val,x,nodes[y].l);//同上
		}
		update(now);
        //由于无论进入哪个判断，作了改变的节点都等于now,所以可以直接更新now。
	}
}
//调用：split(root,v,root1,root2)
```

最后传回的值就相当于给$root1$,$root2$赋值。

$root1$,$root2$就是分裂出的$X$树和$Y$树的根节点。

#### 2>.合并merge

即把两颗像刚刚上面分裂出来的两颗树合并成一棵满足两个性质的树。

我们又要分类讨论：现在需要合并的节点是$x$,$y$。（示例小根堆）

1).$x=0$|$\ $|$y=0$

只有一棵树，直接返回这棵树。

2).$nodes[x].key<nodes[y].key$

$x$节点的键值更小，所以$x$应该在$y$的上面。

$y$的值一定大于$x$,所以把$y$和$x$的右子树进行合并。

3).否则

$y$应该在$x$的上面。

$x$的值一定小于$y$，所以把$y$的左儿子和$x$进行合并。

代码：

```
int merge(int x,int y)
{
	if(!x||!y)	return x+y;
	if(nodes[x].key<nodes[y].key)
	{
		nodes[x].r=merge(nodes[x].r,y);
		update(x);
		return x;
	}
	else
	{
		nodes[y].l=merge(x,nodes[y].l);
		update(y);
		return y;
	}
}
```

学会了这两个操作之后，就可以实现普通平衡树的所有操作了。

#### 3.插入

插入的代码只有两行，非常简单。

只需要把原数按要插入的值$val$大小分裂，一边$x$小于等于$val$，另一边$y$大于$val$。

再把$x$与这个值节点合并（得到$z$），最后与$y$合并。

因为$x$的节点全部小于等于$val$,$z$的节点全部小于$y$。满足我们之前合并两棵树的条件。

代码：
```
void ins(int val)
{
	split(root,val,root1,root2);
   	root=merge(merge(root1,newnode(val)),root2);
}
```

#### 4.删除

先把要删除的值$val$从原树中分裂出来，删掉一个再合并回去。

怎么在很多的$val$中删掉一个呢。

我们把$val$子树根节点的左右节点合并起来，就相当于抛弃了这个根节点。

这样保证了如果有这个值，一定会被删掉，因为如果有，那么根节点肯定有。

代码：
```
void del(int val)
{
	split(root,val,root1,root2);
	split(root1,val-1,root1,root3);
	root3=merge(nodes[root3].l,nodes[root3].r);
	root=merge(merge(root1,root3),root2);
} 
```

#### 5.前驱/后继

我们把小于/大于查询值$val$的子树分裂出来，由于分裂出的子树依然满足二叉树性质，所以我们可以直接查询这个子树中的最大值/最小值，查询出的值就是答案。最后记得合并回去。

代码：
```
int pre(int val)
{
	split(root,val-1,root1,root2);
	int now=root1,res=-INF;
	if(now)
	{
		while(nodes[now].r)	now=nodes[now].r;
		res=nodes[now].num;
	}
	root=merge(root1,root2);
	return res;
}
int nxt(int val)
{
	split(root,val,root1,root2);
	int now=root2,res=INF;
	if(now)
	{
		while(nodes[now].l)	now=nodes[now].l;
		res=nodes[now].num;
	}
	root=merge(root1,root2);
	return res;
}
```

#### 6.第k小

对于这个问题，$fhq-treap$没有特殊的解决方法。所以和$treap$一样。

由于二叉搜索树中序遍历为不降序列，我们分情况讨论：

1>.左子树大小$+1$等于$k$。

说明当前节点就是第$k$小。

2>.左子树大小小于等于$k$

说明第$k$大在左边，那么向左边继续寻找第k小。

3>.否则

第$k$小在右边，但左边和当前结点都比第$k$小。所以第k小是在右边的第$k-nodes[nodes[x].l].sum-1$小。

代码：
```
int top(int val)
{
	int x=root;
	while(x)
	{
		if(nodes[nodes[x].l].sum+1==val)	break;
		if(nodes[nodes[x].l].sum>=val)	x=nodes[x].l;
		else
		{
			val-=(1+nodes[nodes[x].l].sum);
			x=nodes[x].r;
		}
	}
	return nodes[x].num;
}
```

#### 7.排名

排名的定义是比一个数小的数的个数加$1$。

通过定义就能得出做法：

把比查询值小的子树分离出来，这棵子树的大小就是比这个数小的数的个数。再加$1$就能得到答案了。

代码：
```
int rank(int val)
{
	split(root,val-1,root1,root2);
	int res=nodes[root1].sum+1;
	root=merge(root1,root2);
	return res;
}
```

### 2.区间fhq-treap

区间$fhq-treap$维护了一个区间，中序遍历整个$fhq-treap$就可以得到这个序列。当然，这时候它肯定就不能满足二叉搜索树的性质了。但它还可以满足堆的性质。

为了维护区间，我们的$split$操作需要更改：

每次分裂一个区间出来：把这个序列的前$siz$项分出来为一个子树$X$,剩余另一个子树$Y$。

又分类讨论：

1>.$nodes[nodes[x].l].sum<k$
                           
这说明当前结点的左子树和自身都属于 $X$，我们再把右子树的前$k-nodes[nodes[x].l].sum-1$项分给$X$就好了。

2>.否则
  
前$k$项在当前结点的左子树中，那么当前节点和它的右子树属于$Y$。
  
代码：
```
  void split(int now,int siz,int &x,int &y)
{
	if(!now)	x=y=0;
	else
	{
		if(nodes[nodes[now].l].sum<k)
		{
			x=now;
			split(nodes[now].r,siz-nodes[nodes[now].l].sum-1,nodes[x].r,y);
		}
		else
		{
			y=now;
			split(nodes[now].l,siz,x,nodes[y].l);
		}
		update(now);
	}
}
```

但$merge$操作不需要太大变动，只需要加上懒标记下传就行了（如果有的话）

其实区间操作的分裂除了标记下传之外与权值版没有什么差别，只是这里分裂的权值是第k小。
                                      
标记下传是个大坑，有标记时，每当你要对一个节点的子节点进行操作（无论是修改还是查询）时，要先下传标记，否则之后能会传错位置，因为你可能更改了它的子节点。

#### 1.区间和

我们在每个节点中再加上一个变量记录它和它子树的和。

那么每次子树大小更新时，子树和也要更新。

就在$update$里加一句话更新子树和就好。

查询区间和时就把这个区间分裂出来，直接查询这个区间根节点的子树和就行了。

#### 2.区间翻转

区间操作基本靠懒标记来完成。这些标记都会继续下传给子节点。

翻转就用一个$bool$懒标记就好了。

首先说明区间翻转的原理：

先把这个区间分裂出来。
                                      
要使区间翻转，就相当于要把这个区间倒着遍历。
                                      
左中右$->$右中左
  
即我们要对于每个节点遍历时先遍历右边，再遍历本节点，最后遍历左边。
  
那我们把每个节点的左右儿子交换就行了。
  
所以我们直接把这个区间剖出来，把它的根节点打上标记，再合并回去就好了。

#### 3.区间加法

区间加法就像线段树一样的懒标记就好了。
  
其实与区间翻转的实现方式类似，我就不讲了。

#### 4.如何剖出区间[l,r]

我们把序列$[1,n]$分成3段$[1,l-1]$,$[l,r]$,$[r+1,n]$

第一段的长度是$l-1$,第二段的长度是$r-l+1$

我们就挨个把它们$split$出来就好了。

代码:
```
split(root,l-1,root1,root2);
split(root2,r-l+1,root2,root3);
```
$root2$即为$[l,r]$区间的根结点。

$\ $

由此判断，平衡树比线段树还要万能，但常数巨大。
