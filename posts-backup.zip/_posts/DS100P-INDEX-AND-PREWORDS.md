---
title: 数据结构100题系列目录及前言
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-05 14:51:04
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-1.png
mathjax: true
---

# 前言

$\qquad \qquad \qquad$ljs搞了一个dp100题，然后lyc告诉我我们搞一个数据结构100题吧

$\qquad \qquad \qquad$于是我就来了，还带来一个~~网络流~~(它死了，被lyc杀死的)

#### ~~由于某WGY硬是把网络流加进去了，所以我只能重开一个……（我为什么要让他建帖子）~~
$\qquad \qquad \qquad$(它死了，被wgy杀死的)
## ~~我是不会写网络流的！！！~~
$\qquad \qquad \qquad$(它死了，被wgy杀死的)
### 前期我会先把各个数据结构的模板先写一遍，先把基础讲清楚。

$\qquad \qquad \qquad$<a href = "https://image.baidu.com/search/index?tn=baiduimage&ct=201326592&lm=-1&cl=2&ie=gb18030&word=%B9%BE%B9%BE%B9%BE&fr=ala&ala=1&alatpl=adress&pos=0&hs=2&xthttps=111111" class="ui gray label">咕咕咕</a>

### 后期再加一些有价值的题目来讲解。

$\qquad \qquad \qquad$(我可能会先咕掉部分模板……)

$\qquad \qquad \qquad$//先把坑挖好


----

# 题解部分

[$\qquad \qquad \qquad$数据结构100题 1~10题](http://222.180.160.110:1024/article/919)

[$\qquad \qquad \qquad$数据结构100题 11~20题](http://222.180.160.110:1024/article/920)

[$\qquad \qquad \qquad$数据结构100题 21~30题](http://222.180.160.110:1024/article/1083)

# 数据结构学习笔记部分

[$\qquad \qquad \qquad$数据结构100题 ---树状数组](https://www.orchid-any.cf/2020/02/05/DS100P-BINARY-INDEXED-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---fhq-treap](https://www.orchid-any.cf/2020/02/06/DS100P-FHQ-TREAP/)

[$\qquad \qquad \qquad$数据结构100题 ---线段树](https://www.orchid-any.cf/2020/02/07/DS100P-SEGMENT-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---trie树](https://www.orchid-any.cf/2020/02/07/DS100P-TRIE/)

[$\qquad \qquad \qquad$数据结构100题 ---树链剖分](https://www.orchid-any.cf/2020/02/07/DS100P-TREE-CHAIN-SPLITTING/)

[$\qquad \qquad \qquad$数据结构100题 ---主席树](https://www.orchid-any.cf/2020/02/07/DS100P-CHAIRMAN-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---树套树](https://www.orchid-any.cf/2020/02/07/DS100P-TREE-COVER-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---分块](https://www.orchid-any.cf/2020/02/07/DS100P-FENKUAI/)

[$\qquad \qquad \qquad$数据结构100题 ---莫队](https://www.orchid-any.cf/2020/02/07/DS100P-MO-ALGORITHM/)

[$\qquad \qquad \qquad$数据结构100题 ---Link-Cut Tree](https://www.orchid-any.cf/2020/02/07/DS100P-LINK-CUT-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---Chtholly-Tree(Old-Driver Tree)](https://www.orchid-any.cf/2020/02/07/DS100P-CHTHOLLY-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---KMP](https://www.orchid-any.cf/2020/02/07/DS100P-KMP-STRING/)

[$\qquad \qquad \qquad$数据结构100题 ---splay](https://www.orchid-any.cf/2020/02/07/DS100P-SPLAY/)

[$\qquad \qquad \qquad$数据结构100题 ---后缀全家桶 之 后缀数组](https://www.orchid-any.cf/2020/02/07/DS100P-SUFFIX-ARRAY/)

[$\qquad \qquad \qquad$数据结构100题 ---后缀全家桶 之 后缀树](https://www.orchid-any.cf/2020/02/07/DS100P-SUFFIX-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---后缀全家桶 之 后缀自动机](https://www.orchid-any.cf/2020/02/07/DS100P-SUFFIX-AUTOMATON/)

[$\qquad \qquad \qquad$数据结构100题 ---Sqrt-Tree](https://www.orchid-any.cf/2020/02/07/DS100P-SQRT-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---块状数组](https://www.orchid-any.cf/2020/02/07/DS100P-BLOCK-ARRAY/)

[$\qquad \qquad \qquad$数据结构100题 ---块状链表](https://www.orchid-any.cf/2020/02/07/DS100P-BLOCK-LIST/)

[$\qquad \qquad \qquad$数据结构100题 ---树上分块](https://www.orchid-any.cf/2020/02/07/DS100P-BLOCK-LIST/)

[$\qquad \qquad \qquad$数据结构100题 ---猫树](https://www.orchid-any.cf/2020/02/08/DS100P-CAT-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---基环树](https://www.orchid-any.cf/2020/02/08/DS100P-BASE-RING-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---支配树](https://www.orchid-any.cf/2020/02/08/DS100P-DOMINATION-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---左偏树](https://www.orchid-any.cf/2020/02/08/DS100P-DOMINATION-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---环套树](https://www.orchid-any.cf/2020/02/08/DS100P-RING-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---虚树](https://www.orchid-any.cf/2020/02/08/DS100P-VIRTUAL-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---博弈树](https://www.orchid-any.cf/2020/02/08/DS100P-GAME-TREE/)

[$\qquad \qquad \qquad$数据结构100题 ---圆方树](https://www.orchid-any.cf/2020/02/08/DS100P-ROUND-SQUARE-TREE/)