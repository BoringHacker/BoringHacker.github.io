---
title: 数据结构100题 ---Link-Cut Tree
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-07 14:51:04
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-11.png
mathjax: true
---

# Link-Cut Tree

# 0x00

本文的图来自[Qiuly的博客浅谈link-cut Tree](https://www.luogu.com.cn/blog/Qiu/qian-tan-link-cut-tree)

本文照搬[Qiuly的博客浅谈link-cut Tree](https://www.luogu.com.cn/blog/Qiu/qian-tan-link-cut-tree)

lct这东西不好写，我这种蒟蒻写不好所以只能照搬Qiuly，跟Qiuly唯一的区别就是我字是自己打的......

# 0x01

LCT其实可以看做加强版的重链剖分，可以说重链剖分能做的LCT都能做。不仅如此，LCT代码比重链剖分短，常数~~有时~~比重链剖分小。

LCT由很多棵Splay组成，其中将Splay森林中的所有Splay连接起来的叫做 **虚边** 。Splay中边叫做实边。

原来的森林我们叫做原森林，用实边连起来的一棵树叫原树。Splay的关键字是节点在书中的深度。

Splay是LCT的辅助树。fhq-treap其实也可以，但均摊时间复杂度会多出一个\log

# 0x02

以下是一些LCT常用的基础操作

1. `access(x)`:将x到root的路径上的边全部变成实边，并断开与自己儿子的联系
2. `findroot(x)`:找出x所在原树的root
3. `makeroot(x)`:让x变为所在原树的root
4. `connect(x,y)`:连接x和y所在的原树
5. `erase(x,y)`:拆开x和y所在的原树
6. `split(x,y)`:将x,y搞在一棵辅助树

<ul>
<li>
<h1>Access(x):</h1>
<p>换句话来说就是将点x到原树中root之间的链丢到一个splay里</p>
<p>举个例子，现在有一个森林长成这样：</p>
</li>
</ul>
<p><img src="https://i.loli.net/2019/02/23/5c70a02e87a40.png" alt="LCT" /></p>
<p>现在x为6。我们access(x)。</p>
<p>那么{1-3，3-6}会变为实边，1-2会变成<em>虚边</em>，假设6有一儿子n，之间用<strong>实边</strong>连着，那么这条边也将变成<strong>虚边</strong>。</p>
<p>每次将 x 点 <em>splay</em> 到当前所在辅助树的根节点，将它的右儿子更新为上一个 x ，然后令 x 跳到它的父节点，第一个 x 的右儿子设为0。</p>
<pre>为什么是右儿子而不是左儿子呢？

   因为fa[x]的深度小于x，而在Splay里面fa[x]是x的爸爸，所以x在Splay中是fa[x]的右儿子。</pre>
<p><img src="https://i.loli.net/2019/02/23/5c70a02e89ed1.png" alt="LCT" /></p>
<p>我们将 x 旋转到辅助树的根节点，也就是将当前原树这条链上深度小于 x (在 x 上面的点)丢到了 x 的左子树上，将 x 的右子树设为上一个 x 点相当于将 x 原来的右子树丢到了新的 <em>splay</em> 里面(而它们之间用<strong>虚边</strong>相连)，并且将上一段链连接起来。</p>
<p>现在就可以了。这棵新 <em>Splay</em> 中只有这条链上的结点，没有其他任何的结点。如果我们指定要这三个结点同时进行操作，可以直接下传lazy_tag到这三个结点组成的 <em>Splay</em> 的根结点哦!到后面Splay的时候就可以直接下传跟新结点信息了。</p>
<p><strong>总体过程：</strong></p>
<p><img src="https://i.loli.net/2019/02/23/5c70a02e9f825.png" alt="LCT" /></p>
<blockquote>
<p><strong>虚边：儿子认父，父不认子</strong></p>
<p><strong>实边：儿子认父，父也认子</strong></p>
</blockquote>
<p>用FlashHu的话来说：</p>
<blockquote>
<p>1.转到根。</p>
<p>2.换儿子。</p>
<p>3.更新信息。</p>
<p>4.当前操作点切换为轻边所指的父亲，转1。</p>
</blockquote>
<pre><code class="language-cpp">inline void Access(int x){
    for(register int y=0;x;y=x,x=fa[x]){
        Splay(x);//转    ch[x][1]=y;//认儿子了
        pushup(x);//儿子有变化，更新
    }
}</code></pre>
<hr />
<ul>
<li>
<h1>findroot(x):</h1>
</li>
<li>
<p>首先要明白：</p>
<ul>
<li>根节点是的深度最小的</li>
</ul>
</li>
</ul>
<p>我们可以通过x向上找，用 <em>Access</em> 操作可以将x和x的根结点搞到一个 <em>Splay</em> 里。</p>
<p>又因为有BST的性质：x的左子树所有结点的权值 &lt; x &lt; x右子树所有结点的权值。</p>
<p>而我们又知道，在执行完 <em>Access</em> 操作后，这课 <em>Splay</em> 里面的结点权值最大的(深度最大的)就是x。</p>
<p>于是我们可以将x <em>Splay</em> 到这棵 <em>Splay</em> 的根结点，那么现在最左边的节点便是这课树的根结点了。</p>
<pre><code class="language-cpp">inline int findroot(int x){
    Access(x);//Access将x和根结点搞到同一个Splay中
    Splay(x);//转到Splay的根结点
    while(ch[x][0])pushdown(x),x=ch[x][0];//不断的找左儿子&amp;更新节点信息
    return x;//最左边的就是根结点了。
}</code></pre>
<hr />
<ul>
<li>
<h1>makeroot(x):</h1>
<blockquote>
<p>将x到根结点的路径上的点全部翻转(即x变成了根节点)</p>
</blockquote>
</li>
</ul>
<p>具体操作是我们先将x点与原树中的根打通一条链，那么现在它们就在同一棵辅助树里面了，我们发现x一定是在它所在的辅助树的中序遍历的最后一个的(因为它是这条链上最深的点)，我们把x点 <em>splay</em> 到辅助树的根上，那么x显然是没有右子树的，我们要实现将x移到原树的根上，也就是将x到根的这条链的深度全部翻转一遍，在辅助树上的体现就是将整棵树翻转一遍，我们可以写个翻转标记来减少复杂度。</p>
<pre><code class="language-cpp">inline void filp(int x){//Splay普通区间翻转
    swap(ch[x][0],ch[x][1]);r[x]^=1;
} 
inline void makeroot(int x){
    Access(x);
    Splay(x);
    filp(x);//lazy_tag&amp;翻转区间
}</code></pre>
<hr />
<ul>
<li>
<h1>split(x,y)</h1>
</li>
</ul>
<p>这个操作是将x到y之间的那条路径丢到一棵辅助树里，并且这棵辅助树以y节点为根。</p>
<p><em>Splay</em> 维护的是原树中的一条链，我们不能保证x,y会在同一条链里。</p>
<p>所以我们可以先把x变成原树的根节点(这下子Access(y)就会将x到y之间的所有节点丢到一个 <em>Splay</em> 中了)。</p>
<pre><code class="language-cpp">inline void split(int x,int y){
    makeroot(x);Access(y);Splay(y);
} </code></pre>
<hr />
<ul>
<li>
<h1>connect(x,y):</h1>
<blockquote>
<p>将x和y所在原树合并起来</p>
</blockquote>
</li>
</ul>
<p>首先将x点丢到原树的根，然后去找找y的根是不是x，如果不是说明x,y不在一个原树内，我们将x的父节点设为y，也就相当于从y到x连了一条虚边。</p>
<pre><code class="language-cpp">inline void connect(int x,int y){
    makeroot(x);//转到根
    if(findroot(y)!=x)fa[x]=y;//连接一条虚边
    /</code></pre>
<p><img src="https://cdn.luogu.com.cn/upload/pic/49569.png" alt="" /></p>
<hr />
<ul>
<li>
<h1>erase(x,y):</h1>
<p>首先我们先把x,y之间的那条边用split(x,y)拎出来，因为x,y是相邻的，所以y的左儿子一定是x，将它们的父子关系消灭掉即可。</p>
<p>消灭父子关系时一定满足以下条件：</p>
<p>1.x和y在一个原树里(不在一个树里面往哪儿切啊)</p>
<p>2.split之后x是y的左儿子</p>
<p>3.x的右儿子是空的(保证了中序遍历中y紧跟在x的后面，即深度相邻)(x的权值(深度)只比y小1，而x又正好是直接连着y的，所以我们无法再找到 &gt;x 而又 &lt;y 的整数了)</p>
</li>
</ul>
<pre><code class="language-cpp">inline void erase(int x,int y){
    split(x,y);
    if(findroot(y)==x&amp;&amp;fa[x]==y&amp;&amp;!ch[x][1]  fa[x]=ch[y][0]=0;
    }return;
}</code></pre>
<p>但是如果我们在findroot中添加了Splay的话，erase中x和y的父子关系就变了，需要改为这样，否则会出现一些奇奇怪怪的错误：</p>
<pre><code class="language-cpp">inline void erase(int x,int y){
    split(x,y);
    if(findroot(y)==x&amp;&amp;fa[y]==x&amp;&amp;!  fa[y]=ch[x][1]=0;pushup(x);
 de></pre>
<hr />
<ul>
<li>
<h1>0X03 Splay的改动：</h1>
</li>
<li>
<h1>旋转的改动：</h1>
<p>这里需要注意一下，如果x的父亲节点的父亲节点y已经不在当前的这棵辅助树上，只需要连单向边(也就是虚边，认父不认子)，否则正常连就行，这里要和普通的rotate区分开来。</p>
</li>
</ul>
<h2>做个对比：</h2>
<p>现在的rotate(x):</p>
<p>这里的x可以不更新，因为会在下一次rotate时更新。
<pre><code class="language-cpp">inline void rotate(int x){
    int y=fa[x],z=fa[y],k=chk(x),v=ch[x][!k]; 
   x;ch[x][!k]=y,ch[y][k]=v;
    if(v)fa[v]=y;fa[y]=x,fa[x]=z;pushup(y);
}<rotate(x):</p>
<pre><code class="language-cpp">inline void rotate(int x){
    int y=fa[x],z=fa[y],k=chk(x),v=ch[x][!k]; 
   ]=y,ch[y][k]=v;
    fa[v]=y;fa[y]=x,fa[x]=z;pushup(y),pushup(xli>
<h1>Splay的改动</h1>
<p>同样要注意一下只能Splay到辅助树的根节点，Splay之前需先下传一下这一条链上需操作的所有的点，用栈来完成即可</p>
</li>
</ul>
<pre><code class="language-cpp">inline void Splay(int x){
    int y=x,top=0;hep[++top]=y;
    while(get(y))hep[++top]=y=fa[y];
    while(top)pushdown( while(get(x)){//基本普通的Splay
        y=fa[x],top=fa[y];
        rotate((ch[y][0]==x)^(ch[top][0]==y)?x:y);
        rotate(x);
    }pushup(x);return; 
}</code></pre>

最后放一下模板题代码

```cpp
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <queue>
#include <stack>

using namespace std;

const int SIZE = 3e5 + 5;
struct ReadNode {
	template < typename T>
	void operator >> (T &a) {
		a = 0; T f = 1; char ch;
		while (!isdigit(ch = getchar())) if (ch == '-') f = -1;
		while (isdigit(ch)) a = (a << 3) + (a << 1) + (ch ^ '0'), ch = getchar();
		a *= f;
	}
	
	template < typename T>
	void write(T x) {
		if (x < 0) x = -x, putchar('-');
		if (x > 9) write(x / 10);
		putchar(x % 10 + '0');
	}
	
	template < typename T>
	void operator << (T x) {
		write(x);
	}
} win;
int n, q, dis[SIZE];

/******************LinkCutTree******************/

class LinkCutTree {
private:
	struct TreeNode {
		int ch[2];
		int val;
		int sum;
		int rev;
		int fa;
	} T[SIZE + 5];
	int st[SIZE + 5];
	
	inline void exch(int &x, int &y) { x ^= y ^= x ^= y; }
	inline void reverse(int x) { exch(T[x].ch[0], T[x].ch[1]); T[x].rev ^= 1; }
	inline void link(int x, int y, int w) { T[T[x].fa = y].ch[w] = x; }
	inline bool push_up(int x) { return (T[x].sum = T[x].val ^ T[T[x].ch[0]].sum ^ T[T[x].ch[1]].sum), 1; }
	inline void push_down(int x) { T[x].rev && (reverse(T[x].ch[0]), reverse(T[x].ch[1]), T[x].rev = 0); }
	inline void makeroot(int x) { access(x); splay(x); reverse(x); }
	inline void split(int x, int y) { makeroot(x); access(y); splay(y); }
	inline bool isroot(int x) { return (T[T[x].fa].ch[0] ^ x && T[T[x].fa].ch[1] ^ x); }
	inline bool which(int x) { return T[T[x].fa].ch[1] == x; }
	inline void rotate(int x) { int y = T[x].fa, z = T[y].fa, w = which(x); !isroot(y) && (T[z].ch[which(y)] = x), T[x].fa = z, link(T[x].ch[w ^ 1], y, w), link(y, x, w ^ 1), push_up(y), push_up(x); }
	inline void splay(int x) { int y = x, top = 0; while (st[++top] = y, !isroot(y)) y = T[y].fa; while (top) push_down(st[top]), --top; while (!isroot(x)) y = T[x].fa, !isroot(y) && (rotate(which(x) ^ which(y) ? x : y), 0), rotate(x); }
	inline void access(int x) { for (int son = 0; x; x = T[son = x].fa) splay(x), T[x].ch[1] = son, push_up(x); }
	inline int getroot(int x) { access(x), splay(x); while (T[x].ch[0]) push_down(x), x = T[x].ch[0]; return splay(x), x; }
	
public:
	inline void init(int length, int *data) { for (int i = 1; i <= length; ++i) T[i].val = data[i]; }
	inline void connect(int x, int y) { makeroot(x), getroot(y) ^ x && (T[x].fa = y); }
	inline void erase(int x, int y) { makeroot(x), !(getroot(y) ^ x) && !(T[y].fa ^ x) && !(T[y].ch[0]) && (T[y].fa = T[x].ch[1] = 0, push_up(x)); }
	inline void insert(int x, int v) { splay(x), T[x].val = v; }
	inline int find(int x, int y) { return split(x, y), T[y].sum; }
} lct_mast;

/*****************EndLinkCutTree*****************/

signed main() {
	win >> n; win >> q;
	for (int i = 1; i <= n; ++i) win >> dis[i];
	lct_mast.init(n, dis);
	for (int i = 1; i <= q; ++i) {
		int opt, x, y;
		win >> opt; win >> x; win >> y;
		switch(opt) {
		case 0: win << lct_mast.find(x, y), puts(""); break;
		case 1: lct_mast.connect(x, y); break;
		case 2: lct_mast.erase(x, y); break;
		case 3: lct_mast.insert(x, y); break;
		}
	}
	return 0;
}
```