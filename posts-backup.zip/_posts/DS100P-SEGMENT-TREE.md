---
title: 数据结构100题 ---线段树
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-07 14:51:04
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-9.png
mathjax: true
---

# 线段树 --LYC(ZBing)

($nlogn$)

线段树，顾名思义，就是每个树的节点记录一条线段上的一些信息，非常灵活，可以实现很多操作，但常数比树状数组大一点。

就像这样：

![](https://i.loli.net/2019/12/28/qSIgzFlXGQ62xUi.png)

线段树的经典应用就是统计区间和，我们这里也用这个来进行线段树的讲解。

#### 1).建树

我们先放代码吧，看代码理解。

```
void build(int l,int r,int x)
{
    if(l==r)
    {
        nodes[x]=a[l];
        return; 
    }
    else
    {
    	int mid=(l+r)>>1;
    	build(l,mid,x<<1);
    	build(mid+1,r,(x<<1)+1);
    	nodes[x]=nodes[x<<1]+nodes[(x<<1)+1];
	}
}
```

首先，我们遍历到线段树的每一个叶子节点。线段树的每个节点都代表了一个区间，当这个区间的$l=r$时，说明我们到达了叶子节点。这个叶子节点代表的区间只包含了$a[l]$这一个数，所以我们只需要将这个节点的值置为$a[l]$。

然后我们递归回去，每一个非叶子节点都可以把它代表的区间分成两半，对应它的两个子节点（可能没有两个）。它两个子节点的值就是这两个较小区间的元素和。由这两个子节点的值也就是这两个小区间的元素和相加就可以得到当前节点代表区间的元素和。

时间复杂度($nlogn$)

#### 2).单点修改

像这种区间和问题的单点修改一般都是给一个点加上一个值。

还是先放代码吧：

```
void update(int l,int r,int x,int pos,int val)
{
	nodes[x]-=val;
	if(l==r)	return;
	int mid=(l+r)>>1;
	if(pos<=mid)	update(l,mid,x<<1,pos,val);
	else	update(mid+1,r,(x<<1)+1,pos,val);
}
```

还是先递归找到要修改的叶子节点。先将它的值加上val。

然后再递归回去，因为往下找时找到的每一个节点代表的区间都包含这个叶子节点代表的区间，所以这些节点的值也要加上val。

时间复杂度($logn$)

#### 3).区间查询

区间查询的本质就是把要查询的区间拆分成很多小区间，直接利用之前维护的节点的值进行查询。

```
int find(int l,int r,int x,int fr,int ba)
{
	if(l>ba||r<fr)	return 0;
	if(l>=fr||r<=ba)	return nodes[x];
	int mid=(l+r)>>1;
	return find(l,mid,x<<1,fr,ba)+find(mid+1,r,(x<<1)+1,fr,ba);
}
```

我们对于当前递归查找到的节点所代表的区间与要查询的区间进行分类讨论：

$1$>.毫无关联

即当前区间的左端点在查询区间右端点的右边或当前区间的右端点在查询区间左端点的左边。

既然他们毫无关联，那么我们就返回一个值0，因为他们对这个区间的和没有任何贡献。

$2$>.被包含

即当前区间的左端点在查询区间的左端点的右边且当前区间的右端点在查询区间的右端点的左边。

既然这个节点代表的区间全部属于查询区间内，那么我们就没有必要再继续递归下去了，直接把这个节点的值加上去。

$3$>.有部分重叠但不被包含

即上两种情况的剩余情况。

对于这种情况，我们没有办法把节点的值直接加上去，因为这个节点代表的区间不全属于查询区间。也不能直接跳过，因为有部分节点属于查询区间。所以我们继续向它的子节点递归，相当于把这个区间分成两半，查询两个子区间中属于查询区间的值加起来。

时间复杂度（$logn$）

#### 4).区间修改

面对区间修改，如果我们继续用单点修改，时间复杂度会退回到（$n^2logn$）

所以我们引入~~人类的本质~~懒标记。

当我们找到了一个完全是要修改的区间，我们就直接把它的懒标记加上$val$。

对于中途遍历到的其他区间，我们直接计算修改这个区间的和。

代码：

```
void update(int l,int r,int x,int fr,int ba,int val)
{
	if(l>ba||r<fr)	return;
	if(l>=fr&&r<=ba)	lazy[x]+=val;
	else
	{
		nodes[x]+=val*max(0,min(r,ba)-max(l,fr)+1);
		int mid=(l+r)>>1;
		update(l,mid,x<<1,fr,ba,val);
		update(mid+1,r,(x<<1)+1,fr,ba,val);
	}
}
```

~~长得和区间查询很像对吧~~

改了修改之后，我们的查询也要进行修改。要把打上的懒标记进行下传，不然查询到下面的节点时，下面的节点没有被修改。

下传时只需要让当前节点加上原来应加而拖延了的值，让它的左右儿子的懒标记加上它的懒标记。因为当初修改时，并没有修改到左右节点。最后再把懒标记清零。

就像这样：

```
void pushdown(int l,int r,int x)
{
	nodes[x]+=(r-l+1)*lazy[x];
	lazy[x<<1]+=lazy[x];
	lazy[(x<<1)+1]+=lazy[x];
	lazy[x]=0;
}
int find(int l,int r,int x,int fr,int ba)
{
	if(l>ba||r<fr)	return 0;
	if(lazy[x])	pushdown(l,r,x);
	if(l>=fr&&r<=ba)	return nodes[x];
	else
	{
		int mid=(l+r)>>1;
		return find(l,mid,x<<1,fr,ba)+find(mid+1,r,(x<<1)+1,fr,ba);
	}
}
```

$\ $

线段树的讲解到这里就这么完了，但线段树的运用十分广泛，灵活。要熟练掌握并运用线段树，还要多动脑，想好题。
