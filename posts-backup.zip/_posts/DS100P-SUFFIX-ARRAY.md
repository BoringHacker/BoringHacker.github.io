---
title: 数据结构100题 ---后缀全家桶 之 后缀数组
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-07 14:51:04
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-7.png
mathjax: true
incomplete: true
---

# 后缀数组

# 0x01 什么是后缀数组(Suffix Array)

我们知道，对于一个长度为 $n$ 的字符串有 $n$ 个后缀，譬如对于字符串 $DCBAE$ 来说，它的后缀便是:

![img spfaed](https://i.loli.net/2020/01/30/uiheaoRLWdKEON6.png)

那么什么是后缀数组( $SA$ )呢？在我们对字符串的 $n$ 个后缀排序过后，我们定义后缀数组：

> $SA$ 数组：排在第i位的是第 $SA$ [i]个后缀

即后缀数组。

同时我们定义：

>RANK数组：排在第RANK[i]位的后缀是第i个后缀

不难看出RANK和 $SA$ 互逆

![img spfaed](https://i.loli.net/2020/01/30/4jfIt1iy8V9XRPl.png)

# 0x02 如何求出 $SA$ 数组(粗略的)

朴素的做法是直接$sort$，$\Theta(n^2\log n)$ 爹妈恨铁不成钢。

稍微有点脑子都会想到$hash$但是依然爆炸。

如果深入思考的话很容易想到倍增，时间复杂度 $\Theta(n\log n)$ + 大常数碰上毒瘤题当场去世。

$DC3$？常数大，板子难背。

$LUOGU$ 日报曾经有过一片日报给出了一种诱导排序的解决方法，但是我不是很理解。

我在这里给出一种中文互联网上几乎没有任何资料的 $SA$ 数组线性时间复杂度构造方法(我也不知道叫什么名字)。

# 0x03 如何求出 $SA$ 数组(具体的)

首先定义文本串 $text$ 为我们的待求 $SA$ 的字符数组

其次定义 $suffix_i$ 为以 $i$ 起头的 $text$ 的后缀

然后定义 $type_i = \begin{cases}L, suffix_i > suffix_{i+1} \\ 
\displaystyle S, suffix_i < suffix_{i+1}\end{cases}$

参考图片(手写字可能有些看不清楚)：

![img spfaed](https://i.loli.net/2020/01/31/KYgnzM6IZJyoWtL.png)

字符串最后的是什么？你可以认为这是因为作者懒不想到处判边界而加上的**比字符串中任意一个字符的ASCLL码都小的字符**

再来定义 $dist_i$ 为 $text_i$ 距离上一个 $type_i$ 为 $S$ 的距离

参考图片(手写字可能有些看不清楚)：

![img spfaed](https://i.loli.net/2020/01/31/XE3QM7tsHuIPrhx.png)

再定义一个桶 $bucket$，以 $text$ 中的字符为区别桶之间的“键值”。依然参考图片

![img spfaed](https://i.loli.net/2020/01/31/e5xzKhQsH39Ad17.png)

我们其实可以发现此时的 $bucket$ 已经和我们要求的 $SA$ 差的不远了。为什么呢？桶排啊！此时的桶外部其实已经是有序的了，只是我们内部还无法确定顺序。比如 $I$ 这个桶里，我们无法确定 $suffix_{2},suffix_{5},suffix_{8},suffix_{11}$ 的排序顺序，因为他们开头的首字母不同。那该怎么办呢？请继续往下看。

我们再定义一个桶 $D_lists$ “键值” 为 $list_i$。参考图片(注意此时我们不考虑键值(即 $dist$ )为0的情况)

![img spfaed](https://i.loli.net/2020/01/31/HpJhDyjxR8u6iNC.jpg)

以键值为1举一个例子。它的意思就是说 $dist$ 为1的情况有 $suffix_{9},suffix_{3,6}$ 这三种情况。与 $bucket$ 这个桶类似但不同的，我们能分清 $suffix_9$ 和 $sufiix_{3,6}$ 的顺序，但我们无法分清 $suffix_3$ 和 $suffix_6$ 的顺序。为什么呢？我们来看，下标为9的后缀是以 $P$ 开头的，然而下标为3和6的后缀却都是以 $S$ 开头的，所以 $suffix_9$ 一定排在 $suffix_{3,6}$ 的前面。$suffix_{3,6}$ 却因为首字母相同所以无法分清楚顺序。

下一步我们尝试将所有 $type$ 为 $S$ 的 $suffix$ 找出来

我们把 $bucket$ 扫一遍，即可得出：

![img spfaed](https://i.loli.net/2020/02/01/krfWd9FHhPqgtL2.png)

图中的 $S-Substring$ 即为我们所求的所有 $type$ 为 $S$ 的 $suffix$。

同样，我们不知道 $suffix_{2,5,8}$ 哪个在前哪个在后。一种 $naive$ 的做法就是把 $[2,5,8]$ 依次+1，相当于直接暴力比较下一个字母，然后通过 $D_lists$ 来分析它们的先后关系。

![img spfaed](https://i.loli.net/2020/02/01/B6FUGwyXsdW4jkE.png)

我们发现了一个悲剧的事实：已经加到3了，我们却依然无法分清 $[2,5]$ 的顺序。如果继续加下去或许可以分清它们的顺序，但时间复杂度就难以保持在 $\Theta(n)$，换句话说，它很容易被卡。

![img spfaed](https://i.loli.net/2020/02/01/nzZmpYLWh9gkwC8.jpg)

怎么办呢？我们分析一下这种情况出现的原因。

显然此时两个后缀的部分前缀是相同的。即下图的情况：

![img spfaed](https://i.loli.net/2020/02/01/6jyL2qsZ9NMQecE.png)