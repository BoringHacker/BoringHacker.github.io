---
title: 数据结构100题 ---树链剖分
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-07 14:51:04
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-5.png
mathjax: true
---

# 树链剖分

($nlogn$)

树链剖分准确地说并不是数据结构，它只是数据结构的一种应用。

它用于将一棵树上的节点转换到一个序列中，然后用各种数据结构维护。

所以我只讲如何转换和使用，而维护就因题而异了。

树链剖分有好几种方法：重链剖分，长链剖分...

但我就讲最常用的重链剖分。

重链剖分，顾名思义，就是按照节点的子树大小来剖分这棵树。

一个节点子节点中子树大小最大的子节点叫做这个节点的重儿子。

以一个轻儿子为起点，其余全是重儿子的链叫做重链。

重链上的边叫做重边。

就像这样（红色的边为重边）

![树剖.png](https://i.loli.net/2020/01/01/Rgk2A5clbX96JQr.png)

可以发现，每个节点都在且仅在一条重链上，我们就可以把这一条链转换到一个连续的区间来进行维护。

#### dfs1

我们采用dfs的形式来进行剖分，记录信息。

第一次dfs我们需要记录每个节点的父亲，子树大小，重儿子和深度。

很简单对吧，就是暴力$dfs$，但要注意不要搜回到父亲节点和一些其他的坑。

代码：
```
void dfs1(int x,int last)
{
	fa[x]=last;//记录父亲节点。
	sum[x]=1;//初始化子树大小：该节点本身。
	depth[x]=depth[last]+1;//深度：父亲节点深度+1。
	int big=0,bi=0;//寻找重儿子
	for(int i=0;i<e[x].size();++i)
	{
		if(e[x][i]^last)//避免重新回到父亲节点
		{
			dfs1(e[x][i],x);
			sum[x]+=sum[e[x][i]];
			if(sum[e[x][i]]>big)
			{
				big=sum[e[x][i]];
				bi=e[x][i];
			}
		}
	}
	son[x]=bi;//记录重儿子。
}
//调用:dfs(root,root)
```

#### dfs2

经过刚刚$dfs1$的准备，我们可以进行剖分了，这次记录$dfs$序，转换出的序列上的每一个值，以及每个节点所在重链的起点。

我们在这次$dfs$时应该优先走重儿子，这样才能使一条重链上的值都在序列上连在一起，方便我们操作。

代码:
```
void dfs2(int x,int last,bool heavier)
{
	dfn[x]=++tot;//记录dfs序
	turn[tot]=val[x];//记录序列
	if(heavier)	hb[x]=hb[fa[x]];//
	else	hb[x]=x;//记录所在重链起点
	if(b[x].son)	build2(b[x].son,1);//优先遍历重儿子
	for(int i=0;i<e[x].size();++i)
	{
		if(e[x][i]^son[x]&&e[x][i]^fa[x])	build2(e[x][i],0);//避免重复遍历
	}
}
```

一个节点的$dfs$序就是它在序列中的位置。~~对吧~~

#### 使用

对于一些子树上的操作，$dfs$序已经能够搞定了，我们只需要用剖出的重链对那些结点间路径的操作进行应对就好了。

对于两个节点间的路径，我们很容易想到$LCA$。而我们记录了重链的起点，可以处理这条重链，然后直接跳到上面一条重链的末端。

注意当两个节点在同一条重链时跳出循环，在最后处理他们之间的路径。

由于他们已经在同一条重链上了，他们及他们之间的节点$dfs$序是连续的，所以再处理这个连续区间就好了。

代码：
```
//设solve(x,y)是对x到y区间的操作(因题而异) 
___ LCA(int x,int y)
{
	int fx=hb[x],fy=hb[y];//得到重链起点
	while(fx^fy)
	{
		if(depth[fx]<depth[fy])//从深度大的往上跳
		{
			swap(fx,fy);
			swap(x,y);
		}
		solve(dfn[fx],dfn[x]);//处理这条重链的区间
		x=fa[fx];//跳到上面一条重链
		fx=hb[x];//更新重链起点
	}
	solve(min(dfn[x],dfn[y]),max(dfn[x],dfn[y]));//最后处理同一条重链上的剩余未处理部分。
	//return ans;
}
```

___

# 5.主席树

($nlogn$)

“你是主席树吗？有那么多爷爷！”——$LJS$。

这句话运用打比方的说明方法，生动形象地说明了主席树每个节点可能有很多父亲的特点，~~体现说明语言的生动性~~。

也就是说，主席树的几个节点可能共用一个子节点。

就像这样：

![主席树.png](https://i.loli.net/2020/01/11/RV3yh9uzBgWx2EZ.png)

主席树可以用来查询静态区间第k小，静态区间前k大的和等等。（用法十分灵活）

我们会创建很多版本的树，一些版本会共用一些节点，以节省空间和时间。

主席树也叫可持久化线段树。但可持久化还有很多东西。我就讲可持久化线段树吧。

### 1.如何共用节点

我们考虑单点修改的线段树。

如果要得到这个序列某个元素$x$加上一个值$val$之后的新版本，我们发现，改变的只有对应元素$x$的节点和他的祖先会加上$val$。那么其他节点我们可以与上一个版本共用。

所以我们每次新建一个节点，继承之前该位置的值和左右儿子，然后更新值，再继续向下寻找元素$x$的位置，最后递归回来更新这个儿子。

我们使用$root$数组来记录每个版本的根节点编号。

代码：
```
void ins(int l,int r,int pre,int &now,int pos,int val)//区间左右端点，上一个版本中对应这个区间的点，当前版本中对应这个区间的点，修改位置，增加的值。
{
	nodes[++tot]=nodes[pre];//先整个复制
	now=tot;//更新上一个节点的儿子。
	nodes[now].sum+=val;//更新当前节点的值
	if(l==r)	return;
   //向下继续寻找
	int mid=(l+r)>>1;
	if(pos<=mid)	ins(l,mid,nodes[pre].l,nodes[now].l,pos,val);
	else	ins(mid+1,r,nodes[pre].r,nodes[now].r,pos,val);
}
//调用：ins(1,n,root[i-1],root[i],p,v); 
```

最后$root[i]$的引用就相当于记录了这个版本的根节点。

查询其实就和普通的线段树一样，但主席树的用途不止这个。

### 2.例题

[【模板】可持久化线段树 1（主席树）](https://www.luogu.com.cn/problem/P3834)

如题，给定 $n$ 个整数构成的序列，将对于指定的闭区间查询其区间内的第 $k$ 小值。

**权值线段树**：

(线段树的另一种应用，只是每个节点维护整个序列值在$[l,r]$区间内的数的个数)

这道题要求查询静态区间第$k$小。那么对于第$k$小这种问题，我们要使用权值线段树

**离散化**：$-1e9\leq a_i \leq1e9$ 的数据线段树肯定开不下，但这道题只需要求第k小，没有必要开那么大，可以对数据进行离散化。

我们按照序列的顺序插入$a_i$。得到每个$root[i]$代表的权值线段树代表从$a_1$到$a_i$的每个数值的出现次数。

那么根据前缀和的思想，区间$[l,r]$中每个数值的出现个数就是$[1,r]$的减去$[1,l-1]$的。那么数值的区间也具有这个性质。

所有对于每个询问，我们只需要查询一次，用$root[r]$和$root[l-1]$的权值线段树处理出区间$[l,r]$应有的权值线段树，就可以像正常的权值线段树一样查询第k小了。

代码：
```
#include<vector>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,a[200010],x,y,z,cnt,root[200010];
struct node
{
	int l,r,sum;
}nodes[8000010];//40*n
vector<int> v;
void ins(int l,int r,int pre,int &now,int p)//插入，创建新版本
{
	nodes[++cnt]=nodes[pre];
	now=cnt;
	++nodes[cnt].sum;
	if(l==r)	return;
	int m=(l+r)>>1;
	if(p<=m)	ins(l,m,nodes[pre].l,nodes[cnt].l,p);
	else	ins(m+1,r,nodes[pre].r,nodes[cnt].r,p);
}
int find(int l,int r,int p1,int p2,int k)
{
	if(l==r)	return l;
	int m=(l+r)>>1;
	int X=nodes[nodes[p2].l].sum-nodes[nodes[p1].l].sum;//现场处理，得到[x,y]区间内，值在[l,mid]内的数的个数
	if(k<=X)	return find(l,m,nodes[p1].l,nodes[p2].l,k);//如果k<=X.说明第k小的数在左边。
	else	return find(m+1,r,nodes[p1].r,nodes[p2].r,k-X);//否则在右边。
}
int getid(int X)//得到离散化后的数值
{
	return lower_bound(v.begin(),v.end(),X)-v.begin()+1;
}
int main()
{
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
		v.push_back(a[i]);
	}
	sort(v.begin(),v.end());
	v.erase(unique(v.begin(),v.end()),v.end());//离散化
	for(int i=1;i<=n;++i)	ins(1,n,root[i-1],root[i],getid(a[i]));//按顺序插入每个值，得到root[i]对应的权值线段树。
	for(int i=1;i<=m;++i)
	{
		scanf("%d %d %d",&x,&y,&z);
		printf("%d\n",v[find(1,n,root[x-1],root[y],z)-1]);//查询区间[x,y]；输出原值
	}
	return 0;
} 
```

### 3.缺点及注意事项

**内存池一般从1开始用**，$nodes[0]$作为空白，值为$0$，儿子节点指向自己，值还是为$0$。

当你这个版本的树还没有改过某个节点的某个儿子时，这个节点的这个儿子会指向$nodes[0]$，也就相当于下面都是$0$，正好符合。

**数组一定要开大**，如果开得不够大可能会出现$MLE$,$TLE$,$RE$,$WA$.

**但也不要开太大**，不然会$MLE$,$CE$.

**主席树是静态的**，遇到要动态修改而不是生成一个新版本的问题，就可能要用树套树了。

**可持久化可以用在很多数据结构上**，平衡树，线段树，$trie$树......~~可够得写~~，但它们的思想都是相似的，都是每个版本与之前的版本共用节点以节省时间，空间。