---
title: 数据结构100题 ---树套树
author: BoringHacker
avatar: 'https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/icons/avatar.png'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-07 14:51:04
tags: DS100P
keywords:
description:
photos: https://cdn.jsdelivr.net/gh/boringhacker/cdn@1.2/images/posts/post-6.png
mathjax: true
---

# 树套树

($nlog^2n$)

树套树也是一种~~暴力~~思想，它可以有很多实现：树状数组套平衡树，主席树套树状数组......

但是最常见的还是线段数套平衡树。

#### 1.思想&&建树

标准说法：线段树的每个节点对应平衡树的一个节点。

???

其实还是线段树每个节点对应一个区间，但是我们把这个区间建成一棵平衡树就行了，线段树节点记录这个区间建成的平衡树的根节点就行了。

线段树有$logn$层，每层的节点对应的区间能够拼成一个完整的区间，即每层$n$个平衡树节点，平衡树每个节点插入是$logn$的，所以建树的时间复杂度是$nlog^2n$

fhq-treap示例
```
void build(int l,int r,int x)
{
	for(int i=l;i<=r;++i)
	{
		split(root[x],a[i],root1,root2);
		root[x]=merge(merge(root1,newnode(a[i])),root2);
	}
	if(l^r)
	{
		int mid=(l+r)>>1;
		build(l,mid,x<<1);
		build(mid+1,r,x<<1|1);
	}
}
```

#### 2.查询区间排名

给定一个区间和一个值，查询区间中比他小的元素个数加1。

我们可以像线段树一样，先把这个区间拆分成一些能用我们之前建树建出的平衡树表示的小区间，再查询小区间中比这个值小的元素个数加起来的和。

很明显

$$f[i,j]=f[i,k]+f[k+1,j]（i\leq k<j）$$

($f[l,r]$表示区间$[l,r]$中比某个值小的元素个数)

因为$[i,k]$和$[k+1,j]$的元素合在一起就是$[i,j]$的所有元素。

那$[i,k]$和$[k+1,j]$中比某个值小的元素合在一起就是$[i,j]$中比某个值小的元素。

所以上式成立。

时间复杂度：线段树查询$* $平衡树查询$=log^2n$

得出代码写法：
```
int _rank(int &_root,int val)
{
	split(_root,val-1,root1,root2);
	int res=nodes[root1].sum;
	_root=merge(root1,root2);
	return res;
}
int rank(int l,int r,int x,int fr,int ba,int val)
{
	if((l>ba)|(r<fr))	return 0;
	if((l>=fr)&(r<=ba))	return _rank(root[x],val);
	else
	{
		int mid=(l+r)>>1;
		return rank(l,mid,x<<1,fr,ba,val)+rank(mid+1,r,x<<1|1,fr,ba,val);
	}
}
```
#### 3.动态区间第k小

（模版题其实没说这个值要在这个区间内……）

区间动态第k小并不能直接解决。所以我们通过二分寻找这个第k小值。

对每一个二分到的值执行查询排名操作。如果它的排名小于等于k，那么让l等于这个值，否则r等于这个值。

因为第k小值及以下的值的排名都是小于等于k的，从小到大排列的值的排名满足单调性。

时间复杂度：线段树查询$* $平衡树查询$* $二分$=log^3n$

代码：
```
int search(int fr,int ba,int k)
{
    int l=0,r=1e8+1;
	while(l+1<r)
	{
		int mid=(l+r)>>1;
		if(rank(1,n,1,fr,ba,mid)<k)	l=mid;
		else	r=mid;
	}
	return l;
}
```

#### 4.区间前驱/后继

与区间排名类似，只需查询各个分出的子区间中需查询值的前驱/后继，再求出它们的最大/最小值就行了。

时间复杂度：线段树查询$* $平衡树查询$=log^2n$

代码：
```
const int AC=2147483647,WA=-2147483647;
int _pre(int &_root,int val)
{
    split(_root,val-1,root1,root2);
    int now=root1;
    int res=WA;
    if(now)
    {
        while(nodes[now].r) now=nodes[now].r;
        res=nodes[now].num;
    }
    _root=merge(root1,root2);
    return res;
}
int pre(int l,int r,int x,int fr,int ba,int val)
{
	if((l>ba)|(r<fr))  return WA;    
	if((l>=fr)&(r<=ba))	return _pre(root[x],val);
	else
	{
        int mid=(l+r)>>1;
		return max(pre(l,mid,x<<1,fr,ba,val),pre(mid+1,r,x<<1|1,fr,ba,val));
	}
}
int _nxt(int &_root,int val)
{
    split(_root,val,root1,root2);
    int now=root2;
    int res=AC;
    if(now)
    {
        while(nodes[now].l) now=nodes[now].l;
        res=nodes[now].num;
    }
    _root=merge(root1,root2);
    return res;
}
int nxt(int l,int r,int x,int fr,int ba,int val)
{
	if((l>ba)|(r<fr))  return AC;	
	if((l>=fr)&(r<=ba))    return _nxt(root[x],val);
	else
	{
		int mid=(l+r)>>1;
        return min(nxt(l,mid,x<<1,fr,ba,val),nxt(mid+1,r,x<<1|1,fr,ba,val));
	}
}
```

#### 5.修改

依旧是暴力，只需要把所有代表区间中包含需修改位置的节点都修改掉就好了。

如替换值，就把代表区间中包含这个位置的节点代表的平衡树中的原值删除，插入新值就好了。

时间复杂度：线段树寻找$* $平衡树修改$=log^2n$

代码：
```
void modify(int l,int r,int x,int pos,int bef,int the)
{
    split(root[x],bef,root1,root2);
    split(root1,bef-1,root1,root3);
    root3=merge(nodes[root3].l,nodes[root3].r);
    root[x]=merge(merge(root1,root3),root2);

    split(root[x],the,root1,root2);
    root[x]=merge(merge(root1,newnode(the)),root2);

    if(l^r)
    {
        int mid=(l+r)>>1;
        if(pos<=mid)    modify(l,mid,x<<1,pos,bef,the);
        else    modify(mid+1,r,x<<1|1,pos,bef,the);
    }
}
```

#### 6.总结

关于第k小值的操作，据说可以用权值线段树套平衡树(线段树维护值域，平衡树维护在这个值域中的值的位置)在$log^2n$的时间解决。上面教的可能会被卡死。

总而言之，树套树的思想就是暴力。各种数据结构再套一个数据结构（~~线段树套pb_ds~~）。~~其实我也没写过其他的~~。

我这次写得像WGY一样是为什么……