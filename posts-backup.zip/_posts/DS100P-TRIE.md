---
title: 数据结构100题 ---trie树
author: BoringHacker
avatar: 'https://i.loli.net/2020/02/06/fuc7zI8iylU5ANt.jpg'
authorLink: /
authorAbout: 不会打DS的OIER不是萌妹子！
authorDesc: DS100P
categories: Note
comments: true
date: 2020-02-07 14:51:04
tags: DS100P
keywords:
description:
photos: https://i.loli.net/2020/02/06/FNESexpUAbiCBX4.jpg
mathjax: true
---

# trie树

($\sum{len}$)

$trie$树，不是一种二叉树，它是一种多叉树（其实也可以是二叉树）

可以用来求一堆数中两个（或三个）异或起来的最大值。

可以查找单词。

对于一些有前缀的单词，比如*WGY_2333*和*WGY_AND_LYC_WRITE_BLOG*。

它们就可以共用树上的一些节点（即*WGY_*），查询时就可以从$\ $*2*$\ $和$\ $*L*$\ $来对他们进行区分

所以我们还是看看它是怎么实现的吧。

#### 1>.插入

对于$trie$树，树上的每一条边都代表了一个字母或者一个数字。

所以一个节点会有很多儿子，我们就要开一个儿子数组$ch$。

要统计这个节点被经过了多少次，也就是多少单词有这个前缀，就要加一个$sum$。

要统计有多少个单词在这里结束，也就是要查询的单词有多少个已插入的单词作前缀，就要加一个$end$。

插入时，先看这个节点有没有你要走的那个儿子，如果没有，就新建一个，走下去。否则就直接走到这个儿子（共用节点嘛）。

代码：（以小写字母单词为例）
```
struct node
{
	int ch[26],sum,end;
}nodes[MAXN];
int root=1,cnt=1;
void ins(int len)
{
	int x=root;
	for(int i=0;i<len;++i)
	{
		if(!nodes[x].ch[str[i]-'a'])	nodes[x].ch[str[i]-'a']=++cnt;
		x=nodes[x].ch[str[i]-'a'];
		++nodes[x].sum;
	}
	++nodes[x].end;
}
```

#### 2>.查询

$trie$树的查询有很多种，一般依照题目要求来自己定义。

我们这里又以小写字母单词查询存在性为例。

同样是从最上面的根节点开始。如果当前节点有这个单词现在位置字母的儿子，就走下去。否则就直接返回false，因为之前没有过单词走过这条路径,如果有过这个前缀的单词走过，肯定会创建这个节点。

最后再判断有没有单词在这个地方结束。

代码:
```
bool find(int len)
{
	int x=root;
	for(int i=0;i<len;++i)
	{
		if(!nodes[x].str[str[i]-'a'])	return false;
		x=nodes[x].str[str[i]-'a'];
	}
	return nodes[x].end;
}
```

~~trie树就只有这么点，惊不惊喜，意不意外~~